const form = document.getElementById("doubtForm");
const question = document.getElementById("question");
const subject = document.getElementById("subject");
const language = document.getElementById("language");
const askBtn = document.getElementById("askBtn");
const counter = document.getElementById("counter");
const answerSection = document.getElementById("answerSection");
const answer = document.getElementById("answer");
const answerTitle = document.getElementById("answerTitle");
const historyBox = document.getElementById("history");
const clearBtn = document.getElementById("clearBtn");
const copyBtn = document.getElementById("copyBtn");

let history = JSON.parse(localStorage.getItem("doubtHistory") || "[]");

function saveHistory() {
  localStorage.setItem("doubtHistory", JSON.stringify(history.slice(0, 15)));
}

function renderHistory() {
  if (!history.length) {
    historyBox.innerHTML = '<div class="empty">No doubts yet. Ask your first question!</div>';
    return;
  }

  historyBox.innerHTML = history.map((item, index) => `
    <div class="history-item" data-index="${index}">
      <strong>${escapeHTML(item.subject)}</strong>
      <p>${escapeHTML(item.question)}</p>
    </div>
  `).join("");

  document.querySelectorAll(".history-item").forEach(el => {
    el.addEventListener("click", () => {
      const item = history[Number(el.dataset.index)];
      question.value = item.question;
      subject.value = item.subject;
      language.value = item.language;
      updateCounter();
      answerTitle.textContent = `${item.subject} Solution`;
      answer.textContent = item.answer;
      answerSection.classList.remove("hidden");
      window.scrollTo({ top: answerSection.offsetTop - 20, behavior: "smooth" });
    });
  });
}

function escapeHTML(value) {
  return value.replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[char]));
}

function updateCounter() {
  counter.textContent = `${question.value.length} / 1000`;
}

question.addEventListener("input", updateCounter);

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  const q = question.value.trim();
  if (!q) {
    question.focus();
    return;
  }

  askBtn.disabled = true;
  askBtn.textContent = "Solving...";

  try {
    const response = await fetch("/api/ask", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        question: q,
        subject: subject.value,
        language: language.value
      })
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Something went wrong.");

    answerTitle.textContent = `${subject.value} Solution`;
    answer.textContent = data.answer;
    answerSection.classList.remove("hidden");

    history.unshift({
      question: q,
      subject: subject.value,
      language: language.value,
      answer: data.answer
    });
    history = history.slice(0, 15);
    saveHistory();
    renderHistory();

    answerSection.scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (error) {
    answer.textContent = error.message;
    answerSection.classList.remove("hidden");
  } finally {
    askBtn.disabled = false;
    askBtn.textContent = "✨ Solve My Doubt";
  }
});

clearBtn.addEventListener("click", () => {
  history = [];
  localStorage.removeItem("doubtHistory");
  renderHistory();
});

copyBtn.addEventListener("click", async () => {
  await navigator.clipboard.writeText(answer.textContent);
  copyBtn.textContent = "Copied!";
  setTimeout(() => copyBtn.textContent = "Copy", 1200);
});

renderHistory();
updateCounter();
