const express = require("express");
const path = require("path");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const demoAnswers = {
  Mathematics: "Start by identifying the given values and the formula needed. Break the problem into smaller steps, substitute the values carefully, and verify the final result.",
  Programming: "First understand the input and expected output. Choose the appropriate data structure or algorithm, write the logic step by step, and test it with edge cases.",
  DataStructures: "Choose a data structure based on the operation you need most often. For example, arrays are useful for indexed access, stacks follow LIFO, queues follow FIFO, and hash tables provide fast average lookup.",
  DBMS: "DBMS is software used to store, organize, retrieve, and manage data. Important concepts include tables, keys, normalization, SQL, transactions, and relationships.",
  "Computer Networks": "Computer networks allow devices to communicate and share resources. Important topics include OSI/TCP-IP models, IP addressing, routing, TCP, UDP, DNS, and HTTP.",
  "Operating Systems": "An operating system manages hardware and provides services to applications. Key concepts include processes, threads, scheduling, memory management, deadlocks, and file systems.",
  English: "Read the question carefully, identify the grammar or vocabulary rule involved, and construct the answer using clear and simple language."
};

function cleanAnswer(text, subject, language) {
  const base = demoAnswers[subject] || demoAnswers.Programming;
  if (language === "te") {
    return `మీ ప్రశ్నకు సమాధానం: ${base} ప్రశ్నలోని ముఖ్యమైన పదాలను గుర్తించి, దశలవారీగా పరిష్కరించండి.`;
  }
  return base;
}

app.post("/api/ask", (req, res) => {
  const { question, subject = "Programming", language = "en" } = req.body;

  if (!question || !question.trim()) {
    return res.status(400).json({ error: "Please enter a question." });
  }

  // Demo response keeps the project functional without requiring a paid API.
  // Replace this section with your preferred AI provider when you have an API key.
  const answer = cleanAnswer(question.trim(), subject, language);

  res.json({
    answer,
    subject,
    language,
    mode: "demo"
  });
});

app.get("/api/health", (req, res) => {
  res.json({ status: "ok", project: "AI Student Doubt Solver" });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`AI Student Doubt Solver running on port ${PORT}`);
});
